#!/usr/bin/env bash
set -euo pipefail

SKILL_NAME="application-security-baseline"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR"
CANONICAL_ROOT="${XDG_DATA_HOME:-$HOME/.local/share}/agent-skills"
CANONICAL_DIR="$CANONICAL_ROOT/$SKILL_NAME"

mkdir -p "$CANONICAL_ROOT"
rm -rf "$CANONICAL_DIR"
mkdir -p "$CANONICAL_DIR"
cp "$SOURCE_DIR/SKILL.md" "$CANONICAL_DIR/SKILL.md"
[ -f "$SOURCE_DIR/README.md" ] && cp "$SOURCE_DIR/README.md" "$CANONICAL_DIR/README.md"

TARGETS=(
  "$HOME/.claude/skills/$SKILL_NAME"
  "$HOME/.config/opencode/skills/$SKILL_NAME"
  "$HOME/.agents/skills/$SKILL_NAME"
  "$HOME/.gemini/config/skills/$SKILL_NAME"
  "$HOME/.gemini/antigravity-cli/skills/$SKILL_NAME"
)

for target in "${TARGETS[@]}"; do
  mkdir -p "$(dirname "$target")"
  rm -rf "$target"
  ln -s "$CANONICAL_DIR" "$target"
  printf 'Installed: %s -> %s\n' "$target" "$CANONICAL_DIR"
done

echo
printf 'Canonical skill: %s\n' "$CANONICAL_DIR"
printf 'Skill ID: %s\n' "$SKILL_NAME"
printf 'Done. Restart/reload your agents if they were already running.\n'
