# Application Security Baseline — portable agent skill

A cross-agent `SKILL.md` based on the 20 security controls from the supplied image, expanded into an actionable software-engineering security baseline.

## Included controls

1. HSTS
2. CSRF tokens
3. Session reset on password change
4. Expiring/single-use password-reset links
5. User-enumeration resistance
6. Upload-type allowlisting and safe upload handling
7. Payment-webhook verification and idempotency
8. Server-side pricing
9. Prompt-injection resistance
10. AI usage caps
11. Request-size limits
12. Password-reset rate limiting
13. Context-specific validation/sanitization
14. CORS hardening
15. Directory-listing prevention
16. Removal/protection of default admin/debug routes
17. Brute-force/failed-login protection
18. Security-event logging
19. Secure cookie flags
20. Database least privilege

## Why this format

`SKILL.md` is the common cross-tool format supported by current Claude Code, OpenCode, and Google Antigravity skill systems. OpenCode can discover skills from Claude-compatible and agent-compatible global directories, while Antigravity uses `.agents/skills` for workspace scope and `~/.gemini/config/skills` for global scope. See the installation script for the paths used here.

## Install globally on Linux/macOS

```bash
chmod +x install-global.sh
./install-global.sh
```

The installer keeps one canonical copy under `~/.local/share/agent-skills/application-security-baseline/` and links it into common global skill directories:

- `~/.claude/skills/application-security-baseline/`
- `~/.config/opencode/skills/application-security-baseline/`
- `~/.agents/skills/application-security-baseline/`
- `~/.gemini/config/skills/application-security-baseline/`
- `~/.gemini/antigravity-cli/skills/application-security-baseline/`

## Use

The agents should auto-select it when the task is security-sensitive because the frontmatter description is deliberately trigger-oriented.

You can also explicitly invoke the skill where supported with its name:

`application-security-baseline`

In Claude Code/Antigravity/OpenCode installations that expose slash commands for skills, it may also appear as `/application-security-baseline`.
