# Global skill paths

The bundle is designed around the shared `SKILL.md` convention.

| Tool | Global path |
|---|---|
| Claude Code | `~/.claude/skills/application-security-baseline/SKILL.md` |
| OpenCode | `~/.config/opencode/skills/application-security-baseline/SKILL.md` |
| OpenCode compatibility | `~/.claude/skills/...` or `~/.agents/skills/...` |
| Antigravity IDE | `~/.gemini/config/skills/application-security-baseline/SKILL.md` |
| Antigravity CLI | `~/.gemini/antigravity-cli/skills/application-security-baseline/SKILL.md` |
| Generic agent-compatible | `~/.agents/skills/application-security-baseline/SKILL.md` |

The installer creates these links from one canonical copy so the skill does not drift between tools.
