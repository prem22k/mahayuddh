---
name: application-security-baseline
description: Applies a practical application-security baseline when building, reviewing, debugging, or deploying web apps, APIs, authentication, uploads, payments, databases, CORS, cookies, sessions, admin routes, rate limits, or AI features. Use it to proactively check and harden common security controls before shipping, not just after a vulnerability is reported.
---

# Application Security Baseline

Treat security as an engineering constraint, not a final checklist. When a task touches authentication, sessions, password recovery, user input, uploads, payments, APIs, AI/LLM features, CORS, cookies, admin functionality, databases, or deployment, proactively apply the controls below.

Do not blindly add security theater. First inspect the existing architecture, framework, middleware, deployment model, authentication flow, data flow, and threat surface. Then implement the smallest correct control for the actual stack.

## Core rule

For every relevant security control:

1. Inspect the current implementation.
2. Identify the trust boundary and attacker-controlled input.
3. Implement the control on the server/security boundary, not only in the UI.
4. Add or update tests for the abuse case.
5. Verify the control actually works.
6. Report what was fixed, what was not applicable, and any residual risk.

Never claim a control is implemented merely because a client-side check, config value, or TODO exists.

# 20-point baseline

## 1. Add HSTS

For HTTPS production deployments, enable HTTP Strict Transport Security with an appropriate max-age. Include subdomains only when the entire domain tree is HTTPS-safe.

Verify:
- HTTPS is enforced.
- HSTS is emitted on HTTPS responses.
- Do not add `preload` casually; it is an operational commitment.

## 2. Add CSRF tokens

For cookie-authenticated state-changing requests, protect against cross-site request forgery with framework-native CSRF protection or a correctly implemented synchronizer/double-submit token pattern.

Verify:
- POST/PUT/PATCH/DELETE or equivalent state changes are protected where required.
- Tokens are unpredictable and validated server-side.
- SameSite cookies are treated as defense-in-depth, not a universal substitute.

## 3. Reset sessions on password change

When a password is changed or reset, invalidate existing authenticated sessions/tokens that should no longer remain trusted.

Verify:
- Old sessions stop working after password change/reset.
- Refresh tokens, remembered sessions, and device sessions are handled according to the product's security model.

## 4. Expire password-reset links

Password-reset tokens must be single-use, short-lived, securely random, and invalidated after successful use.

Verify:
- Token expiry is enforced server-side.
- Reuse fails.
- A password reset invalidates the token and appropriate sessions.
- Tokens are never logged in plaintext.

## 5. Prevent user enumeration

Do not reveal whether an email/username exists through login, signup, password-reset, or account-recovery responses.

Verify:
- Responses are generic where enumeration matters.
- Status codes, response shapes, and timing do not create an obvious account-existence oracle.
- Do not leak account existence through redirects, error codes, or frontend-only handling.

## 6. Whitelist upload types

Treat uploads as hostile input. Allow only explicitly required file types, validate both declared and actual content where practical, enforce size/count limits, and store untrusted files safely.

Verify:
- Extension allowlists are not the only validation.
- MIME/content sniffing is appropriate for the stack.
- Files cannot become executable server-side.
- Upload names/paths cannot cause traversal.
- Storage is isolated from application execution when practical.

## 7. Verify payment webhooks

Never trust client-side payment success. Verify provider signatures/webhook authenticity server-side and process events idempotently.

Verify:
- Signature verification uses the provider's documented raw payload requirements.
- Duplicate webhook delivery does not double-fulfill orders.
- Event type, merchant/account context, amount, currency, order/reference ID, and state transitions are validated server-side.
- The system does not mark payment complete from an unverified browser redirect.

## 8. Set prices server-side

Never accept authoritative prices, discounts, roles, permissions, or entitlements from the client.

Verify:
- Client sends product/variant identifiers, not trusted final prices.
- Server loads current price and discount rules.
- Totals are recomputed server-side.
- Currency, quantity, stock/eligibility, and authorization are validated server-side.

## 9. Block prompt injection

For AI features, treat external text, retrieved documents, web pages, files, tool output, and user-provided content as untrusted data rather than instructions.

Verify:
- System/developer instructions are not replaced by retrieved or user content.
- Tool permissions follow least privilege.
- Sensitive actions require explicit authorization or confirmation where appropriate.
- Retrieved content cannot directly cause arbitrary tool execution, secret disclosure, permission escalation, or unsafe state changes.
- AI output is not trusted as an authorization decision without deterministic validation.

## 10. Cap AI usage

Put server-side budgets and abuse controls around AI features.

Verify:
- Per-user/account/IP limits exist where appropriate.
- Request/token/output limits exist.
- Expensive tools and models have tighter quotas.
- Rate limits and spend limits fail closed or degrade safely.
- Usage is observable without storing unnecessary sensitive prompt content.

## 11. Limit request size

Limit request body size, URL/query size where relevant, header size where configurable, upload size, batch size, and nested object complexity.

Verify:
- Limits exist at the application and, where possible, reverse-proxy/gateway layer.
- Oversized requests are rejected before expensive processing.
- JSON/parser limits prevent pathological nesting or resource exhaustion.

## 12. Rate-limit password resets

Password-reset and account-recovery endpoints must be abuse-resistant.

Verify:
- Rate limits are server-side.
- Controls consider IP/device/account signals as appropriate without creating an enumeration oracle.
- Repeated requests cannot create unlimited outbound email/SMS cost.
- Successful reset and token issuance have sensible throttling.

## 13. Sanitize before storing

Validate and normalize data at trust boundaries; encode for the output context. Do not use one generic "sanitize everything" function as a substitute for context-specific defenses.

Verify:
- SQL/NoSQL injection risks are addressed with parameterized queries or safe APIs.
- HTML output uses correct output encoding/sanitization.
- Shell commands do not interpolate attacker-controlled strings unsafely.
- File paths, template expressions, URLs, and structured data receive context-specific validation.
- Stored content is revalidated when used in security-sensitive operations.

## 14. Lock down CORS

Allow only the origins, methods, headers, and credentials that the application actually needs.

Verify:
- No wildcard origin is combined with credentialed cross-origin access.
- Production origins are explicit.
- Preflight handling is correct.
- CORS is not confused with authentication or CSRF protection.

## 15. Disable directory listing

Do not expose directory indexes for application, build, upload, backup, config, or log directories unless intentionally required.

Verify:
- Static servers and reverse proxies do not expose unintended listings.
- Hidden files, source maps, backups, and temporary artifacts are reviewed separately.

## 16. Remove default admin routes

Do not ship predictable/default admin endpoints, demo credentials, debug panels, seed accounts, sample secrets, or framework management pages unless intentionally secured.

Verify:
- Default routes are removed or protected.
- Admin surfaces require strong authentication and authorization.
- Non-production debug endpoints are disabled in production.

## 17. Lock accounts after failed logins

Use adaptive throttling/lockout controls to slow credential stuffing and brute-force attacks without creating an easy denial-of-service vector.

Prefer temporary backoff/rate limiting over permanent lockouts. Consider account, IP, device, and risk signals.

Verify:
- Repeated failures increase friction.
- Legitimate users can recover.
- Attackers cannot cheaply lock every account permanently.
- Login and recovery telemetry exists for detection.

## 18. Log security events

Log security-relevant events in a structured, privacy-conscious way.

At minimum consider:
- Authentication success/failure.
- Password/reset/recovery events.
- Session/token revocation.
- Authorization failures.
- Admin/security-sensitive actions.
- Payment verification failures and suspicious webhook events.
- Rate-limit and abuse triggers.
- Upload rejection/security validation failures.
- AI tool/guardrail violations where relevant.

Never log passwords, session tokens, reset tokens, API keys, authorization headers, payment secrets, or sensitive payloads merely for debugging.

## 19. Set secure cookie flags

For authentication/session cookies, configure the strongest flags compatible with the architecture:
- `Secure` for HTTPS.
- `HttpOnly` when JavaScript does not need access.
- Appropriate `SameSite` policy.
- Narrow `Domain`/`Path` scope where possible.
- Explicit expiration/session lifetime.

Verify the actual `Set-Cookie` headers, not just source configuration.

## 20. Restrict database permissions

Use least-privilege database roles and separate credentials by service/environment where practical.

Verify:
- Application users cannot perform unnecessary administrative operations.
- Read/write permissions match service responsibilities.
- Production credentials are not reused in development.
- Secrets are not committed to source control.
- Database/network access is restricted by environment/network policy where possible.

# Security workflow

## A. Before changing code

Inspect:
- Authentication and authorization flow.
- Session/token storage and rotation.
- API routes and middleware.
- Input validation and output rendering.
- Upload/storage path.
- Payment provider integration.
- AI/LLM prompts, retrieval, and tool calls.
- Reverse proxy/deployment headers.
- Database client and credentials.
- Environment/configuration handling.

Map attacker-controlled inputs and privileged operations before editing.

## B. Prioritize

Use this rough order when time is limited:

1. Authentication/session/account recovery.
2. Authorization and privilege boundaries.
3. Remote code execution/injection paths.
4. Payment/financial integrity.
5. Sensitive data exposure.
6. AI tool/action boundaries.
7. Resource exhaustion/abuse controls.
8. Security headers/cookie/CORS hardening.
9. Logging and monitoring.
10. Defense-in-depth cleanup.

Do not let easy header changes distract from broken authorization or insecure business logic.

## C. Implementation rules

- Prefer framework/provider-native security primitives.
- Keep security checks on trusted/server-side boundaries.
- Centralize repeated controls in middleware/services where the architecture supports it.
- Fail closed for authorization and payment verification.
- Make security-sensitive state transitions explicit and idempotent.
- Use cryptographically secure randomness for tokens.
- Avoid inventing cryptography.
- Do not silently weaken an existing security control to make a test pass.
- Preserve backward compatibility only when it does not preserve a known vulnerability.

## D. Testing requirements

For each implemented control, add at least one negative/abuse-case test where practical.

Examples:
- Expired reset token → rejected.
- Reused reset token → rejected.
- Old session after password change → rejected.
- Unknown account on reset → generic response.
- Invalid upload type → rejected.
- Oversized upload/request → rejected.
- Forged payment webhook → rejected.
- Duplicate valid webhook → idempotent.
- Tampered client price → server ignores/recomputes.
- Malicious prompt/retrieved text → cannot override policy/tool permissions.
- Excessive AI requests → throttled.
- Unauthorized CORS origin → rejected/not granted credentials.
- Repeated login failures → throttled/backed off.
- Unauthenticated admin route → rejected.
- Missing/weak cookie flags → fixed and verified.
- Excessive DB operation attempted by app role → denied.

## E. Verification commands

Use the project's existing tooling first. Typical checks include:

- Unit/integration/e2e tests.
- Type checking.
- Linting.
- Production build.
- HTTP/header inspection with `curl -I` or equivalent.
- Dependency/security audit available in the package manager.
- Static analysis or framework security tooling.
- Targeted manual requests against authentication/payment/upload/API endpoints.

Do not substitute a generic scanner for understanding the application's authorization and business logic.

# Decision tree

When a change is proposed, ask:

1. Does it cross a trust boundary? → validate the input and authorization server-side.
2. Does it change authentication or account recovery? → review sessions, token expiry, enumeration, rate limits, and audit logging.
3. Does it involve money or entitlements? → verify signatures, recompute state server-side, and make processing idempotent.
4. Does it accept files? → allowlist, inspect, size-limit, isolate, and safely store.
5. Does it invoke an LLM or tools? → treat content as untrusted, constrain tools, limit usage, and validate outputs.
6. Does it accept network requests? → limit size, rate, origins, methods, and expensive work.
7. Does it set cookies or security headers? → verify actual response headers in the deployed path.
8. Does it touch the database? → enforce least privilege and parameterized/safe queries.
9. Does it add an admin/debug surface? → remove from production or enforce strong authorization.
10. Is the security claim testable? → add a regression test or concrete verification step.

# Output format after a security-hardening task

Report:

### Security changes
- What was changed and why.

### Verification
- Tests/checks run and results.

### Baseline status
- 20 controls: `implemented / not applicable / remaining`.

### Residual risk
- Any known limitations, assumptions, deployment-dependent controls, or controls that require production infrastructure changes.

Never report "secure" as an absolute state. Report concrete controls and remaining risk instead.
